package economypredictor.administration;

public interface Department {
    void showMenu();
    double getTotalSalary();
    String getDepartmentName();
}