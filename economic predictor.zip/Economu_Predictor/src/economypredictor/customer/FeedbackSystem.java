package economypredictor.customer;

public interface FeedbackSystem {
    void recordFeedback(int rating);
    void displayFeedbackSummary();
}