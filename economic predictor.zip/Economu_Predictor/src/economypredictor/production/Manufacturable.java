package economypredictor.production;

public interface Manufacturable {

}
