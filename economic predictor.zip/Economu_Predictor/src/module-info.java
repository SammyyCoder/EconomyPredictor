/**
 * 
 */
/**
 * 
 */
module Economu_Predictor {
}